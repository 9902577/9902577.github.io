            <div class="foot-pay">
                <center>
                    <a href="#">Help and Contact</a>
                    <a href="#">Confidentiality</a>
                    <a href="#">Légal</a>
                    <a href="#">security</a>                
                </center>            
            </div>